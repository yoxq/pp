export const proxy = [
  'https://cors.z13.workers.dev',
  'https://cors.z14.workers.dev',
  'https://cors.z15.workers.dev',
  'https://cors.z16.workers.dev',
  'https://cors.z17.workers.dev',
  'https://cors.z18.workers.dev',
]

export const version = '1.0.0'