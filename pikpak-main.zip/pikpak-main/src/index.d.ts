interface Window {
  $message: any,
  $downId: string[]
}