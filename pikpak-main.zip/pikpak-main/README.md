# PikPak 个人网页版

## 官方地址

 * [PikPak](https://mypikpak.com)

## Demo
 * [PikPak](https://mumuchenchen.github.io/pikpak/)

## 安装部署

### 安装教程
  * [去年夏天版教程](https://www.tjsky.net/?p=201)
### Github Aciton

### Github Page

### Cloudflare Workers
  * [CF Workers实现反代](cf-worker)